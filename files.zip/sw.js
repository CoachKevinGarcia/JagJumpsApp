const CACHE = 'jump-planner-v2';
const ASSETS = [
  '/JagJumpsApp/',
  '/JagJumpsApp/index.html',
  '/JagJumpsApp/manifest.json',
  '/JagJumpsApp/icon.svg'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
  ));
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(r => r || fetch(e.request).catch(() => caches.match('/JagJumpsApp/index.html')))
  );
});
